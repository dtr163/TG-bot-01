#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Тестирование модуля обработки текста
"""

from text_processor import TextProcessor

def test_text_processor():
    """Тестирование всех функций TextProcessor"""
    processor = TextProcessor()
    
    print("🧪 ТЕСТИРОВАНИЕ МОДУЛЯ ОБРАБОТКИ ТЕКСТА")
    print("=" * 50)
    
    # Тестовые тексты
    test_cases = [
        {
            "name": "Нормальный текст",
            "text": "Водитель нарушил правила и вел себя неадекватно",
            "expected_toxic": False
        },
        {
            "name": "Текст с матом",
            "text": "Этот водитель полная сука и мудак",
            "expected_toxic": True
        },
        {
            "name": "Агрессивный текст",
            "text": "УБЬЮ ЭТОГО ИДИОТА!!! ОН ТУПОЙ КАК ПРОБКА!!!",
            "expected_toxic": True
        },
        {
            "name": "Замаскированный мат",
            "text": "Этот б***ь и с*ка ведет себя как х***",
            "expected_toxic": True
        },
        {
            "name": "Длинный текст",
            "text": "Очень длинный текст " * 100,
            "expected_toxic": False
        }
    ]
    
    success_count = 0
    total_count = len(test_cases)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n📝 Тест {i}: {test_case['name']}")
        print(f"Исходный текст: {test_case['text'][:100]}{'...' if len(test_case['text']) > 100 else ''}")
        
        # Обрабатываем текст
        result = processor.process_complaint_text(test_case['text'])
        
        print(f"Обработанный: {result['processed_text'][:100]}{'...' if len(result['processed_text']) > 100 else ''}")
        print(f"Токсичность: {result['final_toxicity']['score']:.2f}")
        print(f"Проблемы: {result['final_toxicity']['issues']}")
        print(f"Изменения: {'Да' if result['changes_made'] else 'Нет'}")
        
        # Проверяем ожидания
        is_toxic = result['final_toxicity']['is_toxic']
        if is_toxic == test_case['expected_toxic']:
            print("✅ Тест пройден")
            success_count += 1
        else:
            print(f"❌ Тест провален (ожидалось: {'токсичный' if test_case['expected_toxic'] else 'нормальный'})")
        
        print("-" * 50)
    
    print(f"\n📊 РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ:")
    print(f"Пройдено: {success_count}/{total_count}")
    print(f"Успешность: {(success_count/total_count)*100:.1f}%")
    
    if success_count == total_count:
        print("🎉 Все тесты пройдены успешно!")
        return True
    else:
        print("⚠️ Некоторые тесты провалены")
        return False

def test_individual_functions():
    """Тестирование отдельных функций"""
    processor = TextProcessor()
    
    print("\n🔧 ТЕСТИРОВАНИЕ ОТДЕЛЬНЫХ ФУНКЦИЙ")
    print("=" * 50)
    
    # Тест очистки мата
    print("\n1. Тест очистки мата:")
    profane_text = "Этот сука и мудак"
    cleaned = processor.clean_profanity(profane_text)
    print(f"Исходный: {profane_text}")
    print(f"Очищенный: {cleaned}")
    
    # Тест снижения агрессии
    print("\n2. Тест снижения агрессии:")
    aggressive_text = "УБЬЮ ЭТОГО ИДИОТА!!!"
    reduced = processor.reduce_aggression(aggressive_text)
    print(f"Исходный: {aggressive_text}")
    print(f"Смягченный: {reduced}")
    
    # Тест нормализации
    print("\n3. Тест нормализации:")
    messy_text = "Текст   с    лишними     пробелами...   и знаками!!!"
    normalized = processor.normalize_text(messy_text)
    print(f"Исходный: '{messy_text}'")
    print(f"Нормализованный: '{normalized}'")
    
    # Тест проверки токсичности
    print("\n4. Тест проверки токсичности:")
    toxic_text = "Этот мудак и идиот!!!"
    is_toxic, score, issues = processor.check_toxicity(toxic_text)
    print(f"Текст: {toxic_text}")
    print(f"Токсичный: {is_toxic}")
    print(f"Оценка: {score:.2f}")
    print(f"Проблемы: {issues}")
    
    # Тест предложений
    print("\n5. Тест предложений по улучшению:")
    bad_text = "что-то там"
    suggestions = processor.suggest_improvements(bad_text)
    print(f"Текст: {bad_text}")
    print(f"Предложения: {suggestions}")

if __name__ == "__main__":
    # Запускаем тесты
    success = test_text_processor()
    test_individual_functions()
    
    print(f"\n{'🎉 ВСЕ ТЕСТЫ ЗАВЕРШЕНЫ УСПЕШНО!' if success else '⚠️ ЕСТЬ ПРОБЛЕМЫ В ТЕСТАХ'}")

