#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegram-бот для сбора жалоб на водителей
Автор: Manus AI
Версия: 1.0
"""

import asyncio
import logging
import re
import os
from datetime import datetime
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict

from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton,
    InputMediaPhoto, InputMediaDocument, InputMediaVideo
)

# Импорт модуля обработки текста
from text_processor import TextProcessor

# Настройки бота
BOT_TOKEN = "7557858368:AAGTBY7345zhffvucjj0RImZo11joyYrg8M"
CHANNEL_ID = "@+keMc18AFgXswYjcy"  # ID канала
ADMIN_USERNAME = "tdr_763"  # Админ без @

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Инициализация бота
bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(storage=storage)

# Инициализация процессора текста
text_processor = TextProcessor()

# Состояния FSM
class ComplaintStates(StatesGroup):
    waiting_for_photo = State()
    waiting_for_name = State()
    waiting_for_number = State()
    waiting_for_date = State()
    waiting_for_location = State()
    waiting_for_description = State()
    waiting_for_fired_status = State()
    waiting_for_rating = State()
    waiting_for_files = State()
    waiting_for_confirmation = State()

# Структура данных жалобы
@dataclass
class Complaint:
    user_id: int
    photo_file_id: Optional[str] = None
    driver_name: str = ""
    driver_number: str = ""
    incident_date: str = ""
    location: str = ""
    description: str = ""
    fired_status: str = ""
    rating: int = 0
    additional_files: list = None
    created_at: str = ""
    
    def __post_init__(self):
        if self.additional_files is None:
            self.additional_files = []
        if not self.created_at:
            self.created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Хранилище жалоб
complaints_storage: Dict[int, Complaint] = {}

# Функция для обработки описания с использованием TextProcessor
def process_description_text(text: str) -> Dict[str, any]:
    """Обработка описания жалобы"""
    return text_processor.process_complaint_text(text, max_length=1000)

def validate_complaint(complaint: Complaint) -> tuple[bool, str]:
    """Проверка полноты данных жалобы"""
    issues = []
    
    if not complaint.driver_name:
        issues.append("Не указано ФИО водителя")
    
    if not complaint.driver_number:
        issues.append("Не указан табельный номер или номер машины")
    
    if not complaint.incident_date:
        issues.append("Не указана дата инцидента")
    
    if not complaint.location:
        issues.append("Не указано место происшествия")
    
    if not complaint.description or len(complaint.description.strip()) < 10:
        issues.append("Описание слишком короткое или отсутствует")
    
    if complaint.rating < 0 or complaint.rating > 10:
        issues.append("Некорректная оценка")
    
    if issues:
        return False, "⚠️ Требует уточнений:\n" + "\n".join(f"• {issue}" for issue in issues)
    
    return True, "✅ Данные полные"

# Клавиатуры
def get_start_keyboard():
    """Стартовая клавиатура"""
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📝 Подать жалобу")],
            [KeyboardButton(text="ℹ️ Информация"), KeyboardButton(text="❓ Помощь")]
        ],
        resize_keyboard=True,
        one_time_keyboard=False
    )
    return keyboard

def get_fired_status_keyboard():
    """Клавиатура для статуса увольнения"""
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Да", callback_data="fired_yes")],
            [InlineKeyboardButton(text="❌ Нет", callback_data="fired_no")],
            [InlineKeyboardButton(text="❓ Неизвестно", callback_data="fired_unknown")]
        ]
    )
    return keyboard

def get_files_keyboard():
    """Клавиатура для дополнительных файлов"""
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📎 Добавить файлы", callback_data="add_files")],
            [InlineKeyboardButton(text="➡️ Продолжить без файлов", callback_data="skip_files")]
        ]
    )
    return keyboard

def get_confirmation_keyboard():
    """Клавиатура подтверждения"""
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ СОГЛАСЕН", callback_data="confirm_complaint")]
        ]
    )
    return keyboard

def get_admin_keyboard(complaint_id: int):
    """Клавиатура для админа"""
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Подтвердить публикацию", callback_data=f"admin_approve_{complaint_id}")],
            [InlineKeyboardButton(text="❌ Отклонить", callback_data=f"admin_reject_{complaint_id}")],
            [InlineKeyboardButton(text="✏️ Редактировать", callback_data=f"admin_edit_{complaint_id}")],
            [InlineKeyboardButton(text="⚠️ Требует уточнений", callback_data=f"admin_clarify_{complaint_id}")]
        ]
    )
    return keyboard

# Обработчики команд
@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    """Обработчик команды /start"""
    welcome_text = """
🤖 Добро пожаловать в бот для подачи жалоб на водителей!

Этот бот поможет вам анонимно подать жалобу на водителя. 
Все данные будут проверены администратором перед публикацией.

🔒 Ваша анонимность гарантирована - никакие личные данные не сохраняются и не публикуются.

Выберите действие:
"""
    
    await message.answer(welcome_text, reply_markup=get_start_keyboard())

@dp.message(F.text == "📝 Подать жалобу")
async def start_complaint(message: types.Message, state: FSMContext):
    """Начало процесса подачи жалобы"""
    user_id = message.from_user.id
    
    # Создаем новую жалобу
    complaints_storage[user_id] = Complaint(user_id=user_id)
    
    await message.answer(
        "📸 Шаг 1/9: Отправьте фото водителя или автомобиля\n\n"
        "Это поможет идентифицировать нарушителя. Фото обязательно для подачи жалобы.",
        reply_markup=types.ReplyKeyboardRemove()
    )
    
    await state.set_state(ComplaintStates.waiting_for_photo)

@dp.message(ComplaintStates.waiting_for_photo, F.photo)
async def process_photo(message: types.Message, state: FSMContext):
    """Обработка фото"""
    user_id = message.from_user.id
    
    if user_id in complaints_storage:
        # Сохраняем file_id самого большого фото
        photo = message.photo[-1]
        complaints_storage[user_id].photo_file_id = photo.file_id
        
        await message.answer(
            "✅ Фото получено!\n\n"
            "👤 Шаг 2/9: Укажите ФИО водителя\n\n"
            "Пример: Иванов Иван Иванович"
        )
        
        await state.set_state(ComplaintStates.waiting_for_name)
    else:
        await message.answer("❌ Ошибка. Начните сначала с команды /start")

@dp.message(ComplaintStates.waiting_for_name, F.text)
async def process_name(message: types.Message, state: FSMContext):
    """Обработка ФИО"""
    user_id = message.from_user.id
    
    if user_id in complaints_storage:
        name = message.text.strip()
        if len(name) < 3:
            await message.answer("❌ ФИО слишком короткое. Попробуйте еще раз:")
            return
        
        complaints_storage[user_id].driver_name = name
        
        await message.answer(
            "✅ ФИО записано!\n\n"
            "🆔 Шаг 3/9: Укажите табельный номер или номер машины\n\n"
            "Пример: А123ВС77 или Таб.№12345"
        )
        
        await state.set_state(ComplaintStates.waiting_for_number)
    else:
        await message.answer("❌ Ошибка. Начните сначала с команды /start")

@dp.message(ComplaintStates.waiting_for_number, F.text)
async def process_number(message: types.Message, state: FSMContext):
    """Обработка номера"""
    user_id = message.from_user.id
    
    if user_id in complaints_storage:
        number = message.text.strip()
        if len(number) < 2:
            await message.answer("❌ Номер слишком короткий. Попробуйте еще раз:")
            return
        
        complaints_storage[user_id].driver_number = number
        
        await message.answer(
            "✅ Номер записан!\n\n"
            "📅 Шаг 4/9: Укажите дату инцидента\n\n"
            "Пример: 06.07.2025 или вчера, сегодня"
        )
        
        await state.set_state(ComplaintStates.waiting_for_date)
    else:
        await message.answer("❌ Ошибка. Начните сначала с команды /start")

@dp.message(ComplaintStates.waiting_for_date, F.text)
async def process_date(message: types.Message, state: FSMContext):
    """Обработка даты"""
    user_id = message.from_user.id
    
    if user_id in complaints_storage:
        date_text = message.text.strip()
        
        # Простая обработка относительных дат
        if date_text.lower() in ['сегодня', 'today']:
            date_text = datetime.now().strftime("%d.%m.%Y")
        elif date_text.lower() in ['вчера', 'yesterday']:
            from datetime import timedelta
            yesterday = datetime.now() - timedelta(days=1)
            date_text = yesterday.strftime("%d.%m.%Y")
        
        complaints_storage[user_id].incident_date = date_text
        
        await message.answer(
            "✅ Дата записана!\n\n"
            "📍 Шаг 5/9: Укажите место происшествия\n\n"
            "Пример: Москва, ул. Тверская, д.1 или Санкт-Петербург, Невский проспект"
        )
        
        await state.set_state(ComplaintStates.waiting_for_location)
    else:
        await message.answer("❌ Ошибка. Начните сначала с команды /start")

@dp.message(ComplaintStates.waiting_for_location, F.text)
async def process_location(message: types.Message, state: FSMContext):
    """Обработка места"""
    user_id = message.from_user.id
    
    if user_id in complaints_storage:
        location = message.text.strip()
        if len(location) < 5:
            await message.answer("❌ Место слишком короткое. Укажите город и адрес:")
            return
        
        complaints_storage[user_id].location = location
        
        await message.answer(
            "✅ Место записано!\n\n"
            "📖 Шаг 6/9: Опишите ситуацию подробно\n\n"
            "Максимум 1000 символов. Избегайте нецензурной лексики.\n"
            "Опишите что произошло, как вел себя водитель, какие были нарушения."
        )
        
        await state.set_state(ComplaintStates.waiting_for_description)
    else:
        await message.answer("❌ Ошибка. Начните сначала с команды /start")

@dp.message(ComplaintStates.waiting_for_description, F.text)
async def process_description(message: types.Message, state: FSMContext):
    """Обработка описания"""
    user_id = message.from_user.id
    
    if user_id in complaints_storage:
        description = message.text.strip()
        
        if len(description) < 10:
            await message.answer("❌ Описание слишком короткое. Опишите ситуацию подробнее:")
            return
        
        if len(description) > 1000:
            await message.answer(f"❌ Описание слишком длинное ({len(description)} символов). Максимум 1000. Сократите:")
            return
        
        # Обрабатываем текст с помощью TextProcessor
        processing_result = process_description_text(description)
        processed_description = processing_result['processed_text']
        
        # Сохраняем обработанное описание
        complaints_storage[user_id].description = processed_description
        
        # Уведомляем пользователя о изменениях, если они были
        response_text = "✅ Описание записано!"
        
        if processing_result['changes_made']:
            response_text += "\n\n⚠️ Текст был автоматически обработан для соответствия правилам публикации."
        
        if processing_result['final_toxicity']['is_toxic']:
            response_text += "\n\n⚠️ В тексте обнаружены проблемы, которые могут потребовать дополнительной модерации."
        
        response_text += "\n\n❌ Шаг 7/9: Был ли водитель уволен?\n\nВыберите один из вариантов:"
        
        await message.answer(
            response_text,
            reply_markup=get_fired_status_keyboard()
        )
        
        await state.set_state(ComplaintStates.waiting_for_fired_status)
    else:
        await message.answer("❌ Ошибка. Начните сначала с команды /start")

@dp.callback_query(ComplaintStates.waiting_for_fired_status)
async def process_fired_status(callback: types.CallbackQuery, state: FSMContext):
    """Обработка статуса увольнения"""
    user_id = callback.from_user.id
    
    if user_id in complaints_storage:
        status_map = {
            "fired_yes": "Да",
            "fired_no": "Нет", 
            "fired_unknown": "Неизвестно"
        }
        
        status = status_map.get(callback.data, "Неизвестно")
        complaints_storage[user_id].fired_status = status
        
        await callback.message.edit_text(
            f"✅ Статус увольнения: {status}\n\n"
            "📊 Шаг 8/9: Оцените водителя от 0 до 10\n\n"
            "0 - ужасно, 10 - отлично\n"
            "Просто напишите цифру:"
        )
        
        await state.set_state(ComplaintStates.waiting_for_rating)
        await callback.answer()
    else:
        await callback.answer("❌ Ошибка. Начните сначала с команды /start")

@dp.message(ComplaintStates.waiting_for_rating, F.text)
async def process_rating(message: types.Message, state: FSMContext):
    """Обработка оценки"""
    user_id = message.from_user.id
    
    if user_id in complaints_storage:
        try:
            rating = int(message.text.strip())
            if rating < 0 or rating > 10:
                await message.answer("❌ Оценка должна быть от 0 до 10. Попробуйте еще раз:")
                return
            
            complaints_storage[user_id].rating = rating
            
            await message.answer(
                "✅ Оценка записана!\n\n"
                "📎 Шаг 9/9: Дополнительные файлы\n\n"
                "Вы можете приложить дополнительные фото, документы или видео для подтверждения жалобы.",
                reply_markup=get_files_keyboard()
            )
            
            await state.set_state(ComplaintStates.waiting_for_files)
            
        except ValueError:
            await message.answer("❌ Введите число от 0 до 10:")
    else:
        await message.answer("❌ Ошибка. Начните сначала с команды /start")

@dp.callback_query(ComplaintStates.waiting_for_files)
async def process_files_choice(callback: types.CallbackQuery, state: FSMContext):
    """Обработка выбора файлов"""
    if callback.data == "add_files":
        await callback.message.edit_text(
            "📎 Отправьте дополнительные файлы:\n\n"
            "• Фото\n"
            "• Документы (PDF, DOC)\n"
            "• Видео\n\n"
            "Когда закончите, напишите 'готово'"
        )
        await callback.answer()
    elif callback.data == "skip_files":
        await show_confirmation(callback.message, state)
        await callback.answer()

@dp.message(ComplaintStates.waiting_for_files, F.text)
async def process_files_done(message: types.Message, state: FSMContext):
    """Завершение добавления файлов"""
    if message.text.lower() in ['готово', 'done', 'готов']:
        await show_confirmation(message, state)

@dp.message(ComplaintStates.waiting_for_files, F.photo | F.document | F.video)
async def process_additional_files(message: types.Message, state: FSMContext):
    """Обработка дополнительных файлов"""
    user_id = message.from_user.id
    
    if user_id in complaints_storage:
        file_info = None
        
        if message.photo:
            file_info = {
                'type': 'photo',
                'file_id': message.photo[-1].file_id,
                'caption': message.caption or ''
            }
        elif message.document:
            file_info = {
                'type': 'document',
                'file_id': message.document.file_id,
                'filename': message.document.file_name or 'document',
                'caption': message.caption or ''
            }
        elif message.video:
            file_info = {
                'type': 'video',
                'file_id': message.video.file_id,
                'caption': message.caption or ''
            }
        
        if file_info:
            complaints_storage[user_id].additional_files.append(file_info)
            await message.answer(
                f"✅ Файл добавлен! Всего файлов: {len(complaints_storage[user_id].additional_files)}\n\n"
                "Отправьте еще файлы или напишите 'готово' для завершения."
            )

async def show_confirmation(message: types.Message, state: FSMContext):
    """Показ подтверждения"""
    confirmation_text = """
⚖️ ЮРИДИЧЕСКОЕ ПОДТВЕРЖДЕНИЕ

Я подтверждаю, что вся информация отправлена мной добровольно. Я принимаю полную юридическую и моральную ответственность за её содержание. Администрация бота и канала ответственности не несут.

⚠️ Внимание: Подача ложной информации может повлечь юридические последствия.

Нажмите кнопку ниже для подтверждения:
"""
    
    await message.answer(
        confirmation_text,
        reply_markup=get_confirmation_keyboard()
    )
    
    await state.set_state(ComplaintStates.waiting_for_confirmation)

@dp.callback_query(ComplaintStates.waiting_for_confirmation)
async def process_confirmation(callback: types.CallbackQuery, state: FSMContext):
    """Обработка подтверждения"""
    if callback.data == "confirm_complaint":
        user_id = callback.from_user.id
        
        if user_id in complaints_storage:
            complaint = complaints_storage[user_id]
            
            # Проверяем данные
            is_valid, validation_message = validate_complaint(complaint)
            
            await callback.message.edit_text(
                "✅ Жалоба принята!\n\n"
                "Ваша жалоба отправлена на модерацию. "
                "После проверки администратором она будет опубликована в канале.\n\n"
                "Спасибо за обращение!"
            )
            
            # Отправляем админу
            await send_to_admin(complaint, is_valid, validation_message)
            
            # Очищаем состояние
            await state.clear()
            
            await callback.answer("Жалоба отправлена на модерацию!")
        else:
            await callback.answer("❌ Ошибка. Начните сначала с команды /start")

async def send_to_admin(complaint: Complaint, is_valid: bool, validation_message: str):
    """Отправка жалобы админу"""
    try:
        # Формируем сообщение для админа
        admin_text = f"""
🔍 НОВАЯ ЖАЛОБА #{complaint.user_id}

👤 ФИО: {complaint.driver_name}
🆔 Номер: {complaint.driver_number}
📅 Дата: {complaint.incident_date}
📍 Место: {complaint.location}
📖 Описание: {complaint.description}
❌ Уволен: {complaint.fired_status}
📊 Оценка: {complaint.rating}/10
📎 Доп. файлы: {len(complaint.additional_files)} шт.

{validation_message}

Время подачи: {complaint.created_at}
"""
        
        # Получаем ID админа
        admin_user = await bot.get_chat(f"@{ADMIN_USERNAME}")
        admin_id = admin_user.id
        
        # Отправляем основное фото
        if complaint.photo_file_id:
            await bot.send_photo(
                chat_id=admin_id,
                photo=complaint.photo_file_id,
                caption=admin_text,
                reply_markup=get_admin_keyboard(complaint.user_id)
            )
        else:
            await bot.send_message(
                chat_id=admin_id,
                text=admin_text,
                reply_markup=get_admin_keyboard(complaint.user_id)
            )
        
        # Отправляем дополнительные файлы
        if complaint.additional_files:
            media_group = []
            for i, file_info in enumerate(complaint.additional_files[:10]):  # Максимум 10 файлов
                if file_info['type'] == 'photo':
                    media_group.append(InputMediaPhoto(
                        media=file_info['file_id'],
                        caption=f"Доп. фото {i+1}" + (f": {file_info['caption']}" if file_info['caption'] else "")
                    ))
                elif file_info['type'] == 'document':
                    media_group.append(InputMediaDocument(
                        media=file_info['file_id'],
                        caption=f"Документ {i+1}" + (f": {file_info['caption']}" if file_info['caption'] else "")
                    ))
                elif file_info['type'] == 'video':
                    media_group.append(InputMediaVideo(
                        media=file_info['file_id'],
                        caption=f"Видео {i+1}" + (f": {file_info['caption']}" if file_info['caption'] else "")
                    ))
            
            if media_group:
                await bot.send_media_group(chat_id=admin_id, media=media_group)
        
        logger.info(f"Жалоба #{complaint.user_id} отправлена админу")
        
    except Exception as e:
        logger.error(f"Ошибка отправки админу: {e}")

# Обработчики админских действий
@dp.callback_query(F.data.startswith("admin_"))
async def process_admin_action(callback: types.CallbackQuery):
    """Обработка действий админа"""
    try:
        action_data = callback.data.split("_")
        action = action_data[1]
        complaint_id = int(action_data[2])
        
        if complaint_id not in complaints_storage:
            await callback.answer("❌ Жалоба не найдена")
            return
        
        complaint = complaints_storage[complaint_id]
        
        if action == "approve":
            # Публикуем в канал
            await publish_to_channel(complaint)
            await callback.message.edit_text(
                f"✅ Жалоба #{complaint_id} опубликована в канале"
            )
            # Удаляем из хранилища
            del complaints_storage[complaint_id]
            
        elif action == "reject":
            await callback.message.edit_text(
                f"❌ Жалоба #{complaint_id} отклонена"
            )
            # Удаляем из хранилища
            del complaints_storage[complaint_id]
            
        elif action == "edit":
            await callback.answer("✏️ Функция редактирования будет добавлена в следующей версии")
            
        elif action == "clarify":
            await callback.message.edit_text(
                f"⚠️ Жалоба #{complaint_id} требует уточнений\n\n"
                "Свяжитесь с пользователем для получения дополнительной информации."
            )
        
        await callback.answer()
        
    except Exception as e:
        logger.error(f"Ошибка обработки админского действия: {e}")
        await callback.answer("❌ Ошибка обработки")

async def publish_to_channel(complaint: Complaint):
    """Публикация жалобы в канал"""
    try:
        # Формируем итоговое сообщение
        channel_text = f"""
🚨 Жалоба на водителя

👤 ФИО: {complaint.driver_name}
🆔 Номер: {complaint.driver_number}
📅 Дата: {complaint.incident_date}
📍 Место: {complaint.location}
📖 Описание: {complaint.description}
❌ Уволен: {complaint.fired_status}
📊 Оценка: {complaint.rating}/10
📎 Приложения: {len(complaint.additional_files) + (1 if complaint.photo_file_id else 0)} файл(ов)

📢 Сообщение отправлено анонимно
"""
        
        # Публикуем основное фото с текстом
        if complaint.photo_file_id:
            await bot.send_photo(
                chat_id=CHANNEL_ID,
                photo=complaint.photo_file_id,
                caption=channel_text
            )
        else:
            await bot.send_message(
                chat_id=CHANNEL_ID,
                text=channel_text
            )
        
        # Публикуем дополнительные файлы
        if complaint.additional_files:
            media_group = []
            for i, file_info in enumerate(complaint.additional_files[:10]):
                if file_info['type'] == 'photo':
                    media_group.append(InputMediaPhoto(media=file_info['file_id']))
                elif file_info['type'] == 'document':
                    media_group.append(InputMediaDocument(media=file_info['file_id']))
                elif file_info['type'] == 'video':
                    media_group.append(InputMediaVideo(media=file_info['file_id']))
            
            if media_group:
                await bot.send_media_group(chat_id=CHANNEL_ID, media=media_group)
        
        logger.info(f"Жалоба #{complaint.user_id} опубликована в канале")
        
    except Exception as e:
        logger.error(f"Ошибка публикации в канал: {e}")

# Дополнительные обработчики
@dp.message(F.text == "ℹ️ Информация")
async def show_info(message: types.Message):
    """Показ информации о боте"""
    info_text = """
ℹ️ Информация о боте

🎯 Назначение: Анонимная подача жалоб на водителей

🔒 Анонимность: Ваши личные данные не сохраняются и не публикуются

📝 Процесс:
1. Заполнение анкеты (9 шагов)
2. Юридическое подтверждение
3. Модерация администратором
4. Публикация в канале

⚖️ Ответственность: Вы несете полную ответственность за достоверность информации

📞 Поддержка: @tdr_763
"""
    
    await message.answer(info_text, reply_markup=get_start_keyboard())

@dp.message(F.text == "❓ Помощь")
async def show_help(message: types.Message):
    """Показ помощи"""
    help_text = """
❓ Помощь

🚀 Как начать:
1. Нажмите "📝 Подать жалобу"
2. Следуйте инструкциям бота
3. Заполните все 9 шагов
4. Подтвердите отправку

📋 Что нужно подготовить:
• Фото водителя или автомобиля
• ФИО водителя
• Табельный номер или номер машины
• Дату инцидента
• Место происшествия
• Подробное описание (до 1000 символов)
• Дополнительные файлы (по желанию)

⚠️ Важно:
• Избегайте нецензурной лексики
• Указывайте только достоверную информацию
• Помните о юридической ответственности

🔄 Команды:
/start - Начать сначала
"""
    
    await message.answer(help_text, reply_markup=get_start_keyboard())

# Обработчик неизвестных сообщений
@dp.message()
async def handle_unknown(message: types.Message):
    """Обработчик неизвестных сообщений"""
    await message.answer(
        "❓ Я не понимаю эту команду.\n\n"
        "Используйте кнопки меню или команду /start",
        reply_markup=get_start_keyboard()
    )

# Основная функция
async def main():
    """Основная функция запуска бота"""
    logger.info("Запуск бота...")
    
    try:
        # Проверяем токен
        bot_info = await bot.get_me()
        logger.info(f"Бот запущен: @{bot_info.username}")
        
        # Запускаем polling
        await dp.start_polling(bot)
        
    except Exception as e:
        logger.error(f"Ошибка запуска бота: {e}")
    finally:
        await bot.session.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Бот остановлен пользователем")
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")

